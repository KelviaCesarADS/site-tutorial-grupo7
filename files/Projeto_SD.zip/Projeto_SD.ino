#include <LiquidCrystal_I2C.h>
#include <Servo.h>

// Endereço e tamanho do display.
// Trocando de 0x3F para 0x27 para verificar a comunicação.
LiquidCrystal_I2C lcd_1(0x27, 16, 2); 

// --- VARIÁVEIS DO SERVO ---
Servo meuServo; 
const int SERVO_PIN = 9;
const int POS_DEFAULT = 180;
const int POS_ACIONAL = 90; 
const long TEMPO_ACAO_SERVO = 2000; // Tempo em milissegundos que o servo fica ACIONADO

// --- VARIÁVEIS DE CONTAGEM E TEMPO ---
const long duracaoContagem = 60000; // 60 segundos 
unsigned long tempoInicio;
unsigned long tempoAcionamentoServo = 0; // Armazena o tempo em que o servo foi acionado

// --- VARIÁVEIS DO BOTÃO ---
const int BOTAO_PIN = 8; 
int estadoBotaoAnterior = HIGH; // Padrão com INPUT_PULLUP
const int centerCol = (16 - 5) / 2; 

// --- VARIÁVEIS PARA EVITAR FLICKER E CENTRALIZAÇÃO ---
int ultimoSegundo = -1; 
bool primeiraInicializacao = true; // FLAG PARA EVITAR ACIONAMENTO INICIAL

// --- DECLARAÇÃO DE FUNÇÃO ---
void initialize_lcd();
void acionarAlimentador();
void limparLinha0(); 
void limparLinha1(); 

// ----------------------------------------------------
//          FUNÇÕES DE LIMPEZA E UTILIDADE
// ----------------------------------------------------

/**
 * Limpa apenas o conteúdo da linha 0 (superior).
 */
void limparLinha0() {
  lcd_1.setCursor(0, 0);
  lcd_1.print("                "); // 16 espaços em branco
}

/**
 * Limpa apenas o conteúdo da linha 1 (inferior).
 */
void limparLinha1() {
  lcd_1.setCursor(0, 1);
  lcd_1.print("                "); // 16 espaços em branco
}

/**
 * Define a mensagem inicial na Linha 0 e restaura o estado padrão.
 */
void initialize_lcd(){
  limparLinha0(); 
  lcd_1.setCursor(0, 0); 
  lcd_1.print("A prox refeicao e:");
}

/**
 * Centraliza a lógica de acionamento do servo e atualiza o display.
 */
void acionarAlimentador() {
    // Só aciona se não estiver já acionado
    if (tempoAcionamentoServo == 0) {
        meuServo.write(POS_ACIONAL); 
        tempoAcionamentoServo = millis(); 
        
        // --- FEEDBACK NA LINHA 0: MENSAGEM DE ATENÇÃO ---
        limparLinha0();
        lcd_1.setCursor(0, 0);
        lcd_1.print("    ATENCAO:    "); // Texto centralizado
        
        // --- FEEDBACK NA LINHA 1 ---
        limparLinha1(); 
        lcd_1.setCursor(centerCol - 2, 1);
        lcd_1.print(" SERVINDO...    "); // Texto com centralização
    }
}

// ----------------------------------------------------
//                SETUP E LOOP
// ----------------------------------------------------

void setup() {
  // Inicialização do LCD
  lcd_1.init();
  lcd_1.backlight();
  lcd_1.clear();
  
  pinMode(BOTAO_PIN, INPUT_PULLUP); 

  // Inicialização do Servo (Define a posição inicial 0°)
  meuServo.attach(SERVO_PIN);
  meuServo.write(POS_DEFAULT); 
  
  initialize_lcd(); // Mostra a mensagem padrão
  tempoInicio = millis();
}

void loop() {
  unsigned long tempoAtual = millis();

  // ------------------------------------
  // 1. Lógica do Botão (Acionamento Manual)
  // ------------------------------------
  int estadoBotaoAtual = digitalRead(BOTAO_PIN); 
  
  if (estadoBotaoAtual == LOW && estadoBotaoAnterior == HIGH) {
    // Ação: Aciona o servo imediatamente
    acionarAlimentador(); 
    ultimoSegundo = -1; // Força a atualização da tela
    primeiraInicializacao = false; // Desativa a flag após a primeira ação
  }
  
  estadoBotaoAnterior = estadoBotaoAtual;

  // -----------------------------------------------------------------------
  // 2. Lógica de Reinício do Servo e Ciclo (Quando a Ação Termina)
  // -----------------------------------------------------------------------
  // Verifica se o servo está ativo E se o tempo de ação já passou
  if (tempoAcionamentoServo > 0 && tempoAtual - tempoAcionamentoServo >= TEMPO_ACAO_SERVO) {
      
      // 1. Volta o servo para a posição inicial
      meuServo.write(POS_DEFAULT); 
      
      // 2. Zera o marcador de acionamento
      tempoAcionamentoServo = 0; 
      
      // 3. RESTAURAÇÃO DA LINHA 0: VOLTA À MENSAGEM ORIGINAL
      initialize_lcd(); 
      
      // 4. Reinicia o contador principal (Novo ciclo começa)
      tempoInicio = tempoAtual; 
      
      // 5. Força a atualização do display para começar a contagem 
      ultimoSegundo = -1;
      
      limparLinha1(); // Limpa a linha 1 para receber a contagem
  }
  
  // ------------------------------------
  // 3. Lógica da Contagem Regressiva e Acionamento Automático
  // ------------------------------------
  long tempoDecorrido = tempoAtual - tempoInicio;
  long tempoRestante = duracaoContagem - tempoDecorrido;

  // Lógica de Acionamento Automático (quando o tempo finaliza)
  if (tempoRestante <= 0) {
    
    // CORREÇÃO: Pula o acionamento se for a primeira vez para iniciar o ciclo completo.
    if (primeiraInicializacao) {
        // Ajusta o contador para um ciclo completo e evita o acionamento
        tempoInicio = tempoAtual;
        primeiraInicializacao = false; // Desativa a flag
        tempoRestante = duracaoContagem;
    } 
    // Se não for a primeira inicialização, aciona o alimentador
    else {
        tempoRestante = 0;
        
        // Ação de Acionamento AUTOMÁTICO - Só aciona se o servo não estiver já acionado
        if (tempoAcionamentoServo == 0) {
            acionarAlimentador();
        }
    }
  } else {
      // Se a contagem já começou, desativa a flag de inicialização
      primeiraInicializacao = false;
  }
  
  // Conversão e Formatação (Somente se não estiver no estado de acionamento)
  if (tempoAcionamentoServo == 0) {
    int totalSegundos = tempoRestante / 1000;
    int minutos = totalSegundos / 60;
    int segundos = totalSegundos % 60;

    // Se o segundo mudou, atualiza o display
    if (segundos != ultimoSegundo) { 
      char bufferTempo[6]; 
      sprintf(bufferTempo, "%02d:%02d", minutos, segundos); 
      lcd_1.setCursor(centerCol, 1);
      lcd_1.print(bufferTempo);
      ultimoSegundo = segundos;
    }
  }
  
  delay(10);
}
