#include <LiquidCrystal_I2C.h>
#include <Servo.h>

LiquidCrystal_I2C lcd_1(0x27, 16, 2); 

Servo meuServo; 
const int SERVO_PIN = 9;
const int POS_DEFAULT = 90;
const int POS_ACIONAL = 25; 
const long TEMPO_ACAO_SERVO = 500;


const long duracaoContagem = 60000;
unsigned long tempoInicio;
unsigned long tempoAcionamentoServo = 0;


const int BOTAO_PIN = 8; 
int estadoBotaoAnterior = HIGH;
const int centerCol = (16 - 5) / 2; 

int ultimoSegundo = -1; 
bool primeiraInicializacao = true;


void initialize_lcd();
void acionarAlimentador();
void limparLinha0(); 
void limparLinha1(); 


void limparLinha0() {
  lcd_1.setCursor(0, 0);
  lcd_1.print("                ");
}


void limparLinha1() {
  lcd_1.setCursor(0, 1);
  lcd_1.print("                ");
}

void initialize_lcd(){
  limparLinha0(); 
  lcd_1.setCursor(0, 0); 
  lcd_1.print("A prox refeicao e:");
}

void acionarAlimentador() {
    
    if (tempoAcionamentoServo == 0) {
        meuServo.write(POS_ACIONAL); 
        tempoAcionamentoServo = millis(); 
        
        
        limparLinha0();
        lcd_1.setCursor(0, 0);
        lcd_1.print("    ATENCAO:    ");
        
        
        limparLinha1(); 
        lcd_1.setCursor(centerCol - 2, 1);
        lcd_1.print(" SERVINDO...    ");
    }
}


void setup() {

  lcd_1.init();
  lcd_1.backlight();
  lcd_1.clear();
  
  pinMode(BOTAO_PIN, INPUT_PULLUP); 

  meuServo.attach(SERVO_PIN);
  meuServo.write(POS_DEFAULT); 
  
  initialize_lcd();
  tempoInicio = millis();
}

void loop() {
  unsigned long tempoAtual = millis();

  int estadoBotaoAtual = digitalRead(BOTAO_PIN); 
  
  if (estadoBotaoAtual == LOW && estadoBotaoAnterior == HIGH) {

    acionarAlimentador(); 
    ultimoSegundo = -1;
    primeiraInicializacao = false;
  }
  
  estadoBotaoAnterior = estadoBotaoAtual;


  if (tempoAcionamentoServo > 0 && tempoAtual - tempoAcionamentoServo >= TEMPO_ACAO_SERVO) {
      
    
      meuServo.write(POS_DEFAULT); 
      
      
      tempoAcionamentoServo = 0; 
      
      
      initialize_lcd(); 
      
      
      tempoInicio = tempoAtual; 
      
      
      ultimoSegundo = -1;
      
      limparLinha1();
  }
  

  long tempoDecorrido = tempoAtual - tempoInicio;
  long tempoRestante = duracaoContagem - tempoDecorrido;


  if (tempoRestante <= 0) {
    
    if (primeiraInicializacao) {
        
        tempoInicio = tempoAtual;
        primeiraInicializacao = false;
        tempoRestante = duracaoContagem;
    } 
    // 
    else {
        tempoRestante = 0;
        
        
        if (tempoAcionamentoServo == 0) {
            acionarAlimentador();
        }
    }
  } else {
      
      primeiraInicializacao = false;
  }
  

  if (tempoAcionamentoServo == 0) {
    int totalSegundos = tempoRestante / 1000;
    int minutos = totalSegundos / 60;
    int segundos = totalSegundos % 60;


    if (segundos != ultimoSegundo) { 
      char bufferTempo[6]; 
      sprintf(bufferTempo, "%02d:%02d", minutos, segundos); 
      lcd_1.setCursor(centerCol, 1);
      lcd_1.print(bufferTempo);
      ultimoSegundo = segundos;
    }
  }
  
  delay(10);
}
